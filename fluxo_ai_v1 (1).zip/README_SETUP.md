# Fluxo — Vercel + Firebase + Assistente IA

Estrutura:

- `index.html` — app Fluxo
- `api/fluxo-ai.js` — rota segura do agente IA no Vercel
- `vercel.json` — configuração do deploy

## Variáveis de ambiente no Vercel

Configure pelo menos uma destas:

- `ANTHROPIC_API_KEY` — mantém o fluxo original do código usando Claude/Anthropic.
- `OPENAI_API_KEY` — fallback usando OpenAI Responses API.

O backend tenta Anthropic primeiro. Se não existir chave Anthropic, usa OpenAI.

Opcional:

- `ANTHROPIC_MODEL` — padrão: `claude-sonnet-4-20250514`
- `OPENAI_MODEL` — padrão: `gpt-5.5`

Depois de criar/alterar variável de ambiente, faça novo deploy no Vercel.
